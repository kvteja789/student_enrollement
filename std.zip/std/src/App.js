
import './App.css';
import AppHeader from './Components/AppHeader';
import PageRouter from "./Components/PageRouter";

const App = (props) => {
  return (
    <>
      <div className="App">
        <AppHeader />
        <PageRouter />
      </div>
    </>
  );
}
export default App;

