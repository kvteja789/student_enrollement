import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import Button from '@material-ui/core/Button';
import { Grid, Paper } from '@material-ui/core';
import { fetchCollegesList } from '../Redux/Actions/CollegeInfoAction';
import { fetchCities } from '../Redux/Actions/CollegeInfoAction';


const CollegeDetails = (props) => {
  const paperStyle = { padding: 20, height: '60vh', width: 370, margin: '70px auto', }
  const container = { width: '100%', height: '90%' }
  const floatLeft = { float: 'left' }

  useEffect(() => {
    props.fetchCollegesList();
    props.fetchCities();
  }, []);
  const clg_details = props.location.collage_details.collegeInfo;
  const history = useHistory();
  const applyForSeat = () => {
    props.history.push('/student-info');
  }
  // if (Object.keys(props.userDetails).length === 0 || props.userDetails.is_login === false) {
  //   props.history.push({
  //     pathname: '/',
  //   })
  // }
  const goBack = (city) => {
    history.push({
      pathname: '/colleges-list',
      city: city
    })
  }
  return (
    <div style={container}>
      <Grid>
        <Paper elevation={10} style={paperStyle}>
          <Grid><h3>College Details</h3></Grid>
          <div style={{ width: '75%', height: '40%', margin: 'auto' }}>
            <span style={floatLeft}>Name : {clg_details.name}</span><br />
            <span style={floatLeft}>City : {clg_details.city}</span><br />
            <span style={floatLeft}>Code : {clg_details.code}</span><br />
            <span style={floatLeft}>Start : {clg_details.year}</span><br />
            <span style={floatLeft}>Hostel Facility : {clg_details.hostelFacility}</span><br />
            <span style={floatLeft}>Address : {clg_details.address}</span><br />
            <span style={floatLeft}>Email : {clg_details.email}</span><br />
            <span style={floatLeft}>Contact : {clg_details.contact}</span>          
          </div>
          <br></br><br></br>
          <Button onClick={() => goBack(clg_details.city)} variant="contained" type="submit" color="primary">Back</Button>
          <br /><br />     <Button onClick={applyForSeat} variant="contained" type="submit" color="primary">Apply</Button>
          {props.is_error ? <p style={{ color: 'red' }}>Your Credentials are not matched!</p> : null}
        </Paper>
      </Grid>
    </div>
  )
}
const mapStateToProps = state => {
  return {
    userDetails: state.login.userDetails,
    collegesList: state.colleges.collegesList,
  }
}
const mapDispatchToProps = dispatch => {
  return {
    fetchCollegesList: () => dispatch(fetchCollegesList()),
    fetchCities: () => dispatch(fetchCities())
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(CollegeDetails);
