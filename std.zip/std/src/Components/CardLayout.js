import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import { connect } from 'react-redux';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import CardActions from '@material-ui/core/CardActions';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles({
  card: {
    maxWidth: 250,
    display: 'flex',
    padding: 20,
    margin: 10,
    alignItems: 'center',
    float: 'left',
    flexDirection: 'column'
  },
  media: {
    height: 100,
  },
  noData: {
    textAlign: 'center',
    margin: 'auto',
    marginTop: 20
  }
});

const CardLayout = (props) => {
  const classes = useStyles();
  console.log('inside cardlayout-props-',props.location.admission_info);
  const admission_info = props.location.admission_info;
//   const books_info = props.location && props.location.book_details ?
//     props.location.book_details : props.selectedBook;

//   const checkBookStatusHandler = (book_id,ud) => {
//     const final = props.rentBooks.filter(value => {
//       return (value.id === book_id && value.user_name === ud.user_name) 
//       ? true : false;
//     });
//     return (final.length > 0 ? true : false);
//   }
//   return (
//     <>
//       {Object.entries(books_info).length === 0 ? <span className={classes.noData}>No Data Found </span> : null}
//       {
//         books_info.map(book => {
//           return (
//             <Card className={classes.card} key={book.id}>
//               <CardActionArea>
//                 <CardMedia
//                   className={classes.media}
//                   image={book.img}
//                   title="Contemplative Reptile"
//                 />
//                 <CardContent>
//                   <Typography gutterBottom component="h5">
//                     Title: {book.title}
//                   </Typography>
//                   <Typography variant="body2" color="textSecondary" component="p">
//                     Author: {book.author}
//                   </Typography>
//                   <Typography variant="body2" color="textSecondary" component="p">
//                     user_name: {props.userDetails.user_name}
//                   </Typography>
//                 </CardContent>
//               </CardActionArea>
//               <CardActions>
//                 {
//                   checkBookStatusHandler(book.id,props.userDetails) && props.userDetails.login_type == 2 ?
//                     <>
//                       <Button onClick={() => props.viewBookHandler(book)} size="small" color="primary">
//                         view
//                       </Button>
//                       <Button onClick={() => props.cancelBookRequestHandler(book)} size="small" color="primary">
//                         cancel request
//                     </Button>
//                       <Button disabled size="small" color="primary">
//                         Waiting For Approval
//                     </Button></> :
//                     props.userDetails.login_type == 2 ?
//                       <>
//                         <Button onClick={() => props.viewBookHandler(book)} size="small" color="primary">
//                           view
//                       </Button>
//                         <Button onClick={() => props.bookForRentHandler(book)} size="small" color="primary">
//                           Book For Rent
//                       </Button>
//                       </> :
//                       <>
//                         <Button size="small" color="primary">
//                           Approve
//                       </Button>
//                         <Button size="small" color="primary">
//                           Denied
//                       </Button>
//                       </>
//                 }
//               </CardActions>
//             </Card>
//           )
//         })
//       }
//     </>
//   )

return (
    <>
      {
        admission_info.map(book => {
          return (
            <Card className={classes.card} key={book.id}>
              <CardActionArea>
                <CardContent>
                  <Typography gutterBottom component="h5">
                    Name: {book.name}
                  </Typography>
                  <Typography variant="body2" color="textSecondary" component="p">
                    Age: {book.age}
                  </Typography>
                </CardContent>
              </CardActionArea>
              
            </Card>
          )
        })
      }
    </>
  )

   //  return <div>inside cardlayout </div>
}
const mapStateToProps = state => {
  return {
  }
}
export default connect(mapStateToProps, false)(CardLayout);