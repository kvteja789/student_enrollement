import {  TextField } from '@material-ui/core';
export const TextFieldComponent = (props) =>{
    return   <TextField required type={props.type} label={props.label} name={props.name} 
    placeholder={props.placeholder} onChange={props.onchangeHandler}  />
}