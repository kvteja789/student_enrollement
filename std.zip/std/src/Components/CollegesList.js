import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { fetchCollegesList } from '../Redux/Actions/CollegeInfoAction';
import { fetchCities } from '../Redux/Actions/CollegeInfoAction';
import { Select, MenuItem, InputLabel, FormControl } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';

const CollegesList = (props) => {
  const history = useHistory();
  const cityName = props.location.city;
  const [city, setCity] = useState();
  const [collegesList, setCollegesList] = useState([]);

  const useStyles = makeStyles({
    noData: {
      textAlign: 'center',
      margin: 'auto',
      marginTop: 20
    },
    card: {
      maxWidth: 450,
      margin: 'auto',
      marginTop: 10,
      alignItems: 'center'
    },
    media: {
      height: 100,
    },
  });

  const classes = useStyles();
  useEffect(() => {
    props.fetchCollegesList();
    props.fetchCities();
  }, []);

  const updateSelectVal = (city) => {
    const selectedCity = city;
    let selectedColleges = props.collegesList.filter(value => {
      return (value.city === selectedCity);
    });
    setCollegesList(selectedColleges);
  }
  const showCollegeDetails = (details) => {
    history.push({
      pathname: '/college-details',
      collage_details: details
    })
  }
  // if(cityName !== undefined){
  //     //debugger;
  //     return updateSelectVal(cityName);
  // }
  // if (Object.keys(props.userDetails).length === 0 || props.userDetails.is_login === false) {
  //   history.push({
  //     pathname: '/',
  //   })
  // }
  return (
    <>
      <h1>Select your college from dropdown</h1>
      <FormControl>
        <InputLabel>select city</InputLabel>
        <Select style={{ width: 150 }} value={city} onChange={(e) => updateSelectVal(e.target.value)}>
          {props.cities && props.cities.map((item, index) => <MenuItem key={index} value={item} >{item}</MenuItem>)}
        </Select>
      </FormControl>
      <br /><br />
      {
        collegesList && collegesList.map(item => {
          return (
            <Card className={classes.card} key={item.id} onClick={() => showCollegeDetails(item)}>
              <CardActionArea>
                <CardContent>
                <Typography gutterBottom component="h5">
                    City: {item.city}
                  </Typography>
                  <Typography gutterBottom component="h5">
                    Collage Name: {item.collageName}
                  </Typography>
                  <Typography variant="body2" color="textSecondary" component="p">
                    Area: {item.city}
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          )
        })
      }
    </>
  )
}
const mapStateToProps = state => {
  return {
    userDetails: state.login.userDetails,
    collegesList: state.colleges.collegesList,
    cities: state.colleges.cities
  }
}
const mapDispatchToProps = dispatch => {
  return {
    fetchCollegesList: () => dispatch(fetchCollegesList()),
    fetchCities: () => dispatch(fetchCities())
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(CollegesList);




