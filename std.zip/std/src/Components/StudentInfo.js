import React, { useState } from 'react';
import { connect } from 'react-redux';
import Button from '@material-ui/core/Button';
import { Grid, Paper } from '@material-ui/core';
import { TextFieldComponent } from "./TextFieldComponent";
import {applyForAdmission} from '../Redux/Actions/ApplyForAdmissionAction';
import { useHistory } from 'react-router-dom';

const StudentInfo = (props) => {
    const history = useHistory();
    const paperStyle = { padding: 20, height: '60vh', width: 320, margin: '70px auto', }
    const container = { width:'100%',height:'90%'}
    const [studentDetails, setStudentDetails] = useState({name: '',age: '',});
    const changeHandler = (e) => {
        const { name, value } = e.target;
        setStudentDetails({ ...studentDetails, [name]: value });
    }
    const onSubmitHandler = (e) => {
        console.log('inside onsubmit handler-',studentDetails);
        e.preventDefault();  
        props.applyForAdmission(studentDetails);
    }
    // const goBack = () =>{ 
    //     history.push({
    //         pathname : '/college-details'
    //     })
    // }
    return (
        <div style={container}>
            <Grid>
                <form onSubmit={(e) => onSubmitHandler(e)}> 
                    <Paper elevation={10} style={paperStyle}>
                        <Grid><h4>Enter Your Details</h4></Grid>
                        <TextFieldComponent type="text" label="Name"  name="name"
                            placeholder="Name" onchangeHandler={changeHandler} />
                        <TextFieldComponent type="number" label="Age"  name="age"
                            placeholder="Age" onchangeHandler={changeHandler} />
                        <TextFieldComponent type="text" label="Father name" name="fathername"
                            placeholder="Father name" onchangeHandler={changeHandler} />
                        <TextFieldComponent type="number" label="Contact number"  name="contactnumber"
                            placeholder="Contact number" onchangeHandler={changeHandler} />
                        <br></br><br></br>
                        <Button variant="contained" type="submit" color="primary">Back</Button>
                        <br/><br/>
                        <Button variant="contained" type="submit" color="primary">submit</Button>
                        {props.is_error ? <p style={{color:'red'}}>Your Credentials are not matched!</p> : null}
                    </Paper>
                </form>
            </Grid>
        </div>
    )
}
const mapStateToProps = state => {
    return {
        is_login: state.login.userDetails.is_login,
        is_error: state.login.userDetails.is_error,
        userDetails: state.login.userDetails
    }
};
const mapDispatchToProps = (dispatch) => {
    return {
        applyForAdmission: (details) => dispatch(applyForAdmission(details)),

    };
};
export default connect(mapStateToProps, mapDispatchToProps)(StudentInfo);