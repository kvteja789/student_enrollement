import React, { useState } from 'react';
import { connect } from 'react-redux';
import Button from '@material-ui/core/Button';
import { Grid, Paper, TextField } from '@material-ui/core';
import { UserLogin } from '../Redux/Actions/LoginAction';
import { useHistory } from 'react-router-dom';

const LoginScreen = (props) => {
    const history = useHistory();
    const paperStyle = { padding: 20, height: '45vh', width: 320, margin: '85px auto', }
    const container = { width:'100%',height:'90%',position:'absolute',
    backgroundImage: `url("https://www.bing.com/th/id/OIP.AFLoXaHE-tj9d6VGtZ_OJQHaE9?pid=Api&rs=1")`,
    backgroundRepeat:'no-repeat',backgroundPosition:'center',backgroundSize:'cover'}
    const [loginDetails, setLoginDetails] = useState({name: '',password: '',});
   
    const changeHandler = (e) => {
        const { name, value } = e.target;
        setLoginDetails({ ...loginDetails, [name]: value });
    }
    const onSubmitHandler = (e) => {
        e.preventDefault();  
        props.fetchAuthDetails(loginDetails);
    }
  //  console.log('this is login screen - ',props.login.is_login);
    if (props.isLogin === true) {
      history.push('/colleges-list')
    }
    //if (props.is_login) history.push('/colleges-list');
    return (
        <div style={container}>
            <Grid>
                <form onSubmit={(e) => onSubmitHandler(e)}> 
                    <Paper elevation={10} style={paperStyle}>
                        <Grid>
                            <h4>Login</h4>
                        </Grid>
                        <TextField required type="text" label="User Name" value={loginDetails.name} name="name"
                            placeholder="Enter your user name" onChange={changeHandler} />
                        <TextField required type="password" label="Password" value={loginDetails.password} name="password"
                            placeholder="Enter your password" onChange={changeHandler} />
                        <br></br><br></br>
                        <Button variant="contained" type="submit" color="primary">submit</Button>
                        {props.is_error ? <p style={{color:'red'}}>Your Credentials are not matched!</p> : null}
                    </Paper>
                </form>
            </Grid>
        </div>
    )
}
const mapStateToProps = state => {
    return {
        is_login: state.login.userDetails.is_login,
        is_error: state.login.userDetails.is_error,
        userDetails: state.login.userDetails,
        isLogin: state.login.is_login
    }
};
const mapDispatchToProps = (dispatch) => {
    return {
        fetchAuthDetails: (details) => dispatch(UserLogin(details)),
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(LoginScreen);