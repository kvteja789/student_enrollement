import React from 'react';
import { connect } from 'react-redux';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import { logout } from '../Redux/Actions/LoginAction'; 
import { fetchStudentAdmissionInfo } from '../Redux/Actions/ApplyForAdmissionAction';
import Badge from '@material-ui/core/Badge';
import NotificationsNoneIcon from '@material-ui/icons/NotificationsNone';
import { NavLink } from 'react-router-dom';
import { useHistory } from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1
  },
  title: {
    flexGrow: 1,
  },
  textColor: {
    color: 'white'
  }
}));

function AppHeader(props) {
  const classes = useStyles();
  const history = useHistory();
  const getApplications = () =>{
    props.fetchStudentAdmissionInfo();
    console.log('inside -AppHeader-studenAdmInfo-',props.studenAdmInfo);
    if(props.studenAdmInfo){
      history.push({
        pathname: '/card-layout',
        admission_info: props.studenAdmInfo
      })
    }

  }
  const doLogout = () => {
    console.log('AppHeader comp inside doLogout method-');
    history.push('/');
    props.logout();
  }
  console.log('inside -app header-studenAdmInfo-',props.studenAdmInfo);
  return (
    <div className={classes.root}>
      <AppBar position="static" color="secondary" style={{ backgroundColor: '#563a86' }}>
        <Toolbar>
          <Typography variant="h6" className={classes.title}>
            STUDENT ENROLEMENT
          </Typography>
          {
            props.isLogin ?
              <>
                {(props.count || props.studenAdmInfo.length) ?
                  <Badge  anchorOrigon={{ vertical: 'top', horizontal: 'left' }} badgeContent={props.count || props.rentBooks.length} color="primary">
                    <NotificationsNoneIcon onClick={getApplications} />
                  </Badge> : null}
                <Button className={classes.textColor}>{props.userDetails.user_name}</Button>
                <Button className={classes.textColor} onClick={doLogout}>Logout</Button></>
              : null
          }
        </Toolbar>
      </AppBar>
    </div>
  );
}
const mapStateToProps = state => {
  return {
    userDetails: state.login.userDetails,
    count: state.admission.admissionCount,
    studenAdmInfo: state.admission.studentAdmissionInfo,
    isLogin: state.login.is_login
  }
}
const mapDispatchToProps = dispatch => {
  return {
    logout: () => dispatch(logout()),
    fetchStudentAdmissionInfo: () => dispatch(fetchStudentAdmissionInfo())
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(AppHeader);



