
import { connect } from 'react-redux';
import { Route, BrowserRouter as Router, Switch } from 'react-router-dom';
import { useHistory } from 'react-router-dom';
import LoginScreen from './LoginScreen';
import CollegesList from './CollegesList';
import CollegeDetails from './CollegeDetails';
import StudentInfo from './StudentInfo';
import CardLayout from './CardLayout';

const PageRouter = (props) => {
  const history = useHistory();
  console.log('PageRouter comp props.isLogin-',props.isLogin);
  // if (props.isLogin === true) {
  //   console.log('PageRouter comp inside if block props.isLogin-',props.isLogin);
  //   history.push('/');
  // }
  return (
    <Switch>
      <Route exact path='/' component={LoginScreen} />
      {props.isLogin == true ?
        <>
          <Route path='/colleges-list' component={CollegesList} />
          <Route path='/college-details' component={CollegeDetails} />
          <Route path='/student-info' component={StudentInfo} />
          <Route path='/card-layout' component={CardLayout} />
        </>
        : null}
    </Switch>
  );
}

const mapStateToProps = state => {
  return {
    userDetails: state.login.userDetails,
    isLogin: state.login.is_login
  }
};
export default connect(mapStateToProps)(PageRouter);

