const validateCredentials = (user, user_creds) => {
  let obj = {
    user_name: '',
    is_error: false,
    login_type: 1,
    is_login: false
  };
  if ((user.id == user_creds.name) && (user.password == user_creds.password)) {
    if (user.id === 'admin') obj.login_type = 1; //Librarian type
    else obj.login_type = 2; // Member type       
    obj.is_error = false;
    obj.is_login = true;
    obj.user_name = user.id;
  }
  else {
    obj.is_error = true;
    obj.is_login = false;
  }
  return obj;
}
export default validateCredentials;