const initialState = {
    collegesList:[],
    cities:[],
    error:'',
  }
  const collesListReducer = (state = initialState,action) =>{
    switch(action.type){
      case 'FETCH_COLLEGES_SUCCESS':
        return{
          ...state,
          collegesList:action.payload,
          error:''
        }
      case 'FETCH_COLLEGES_FAILURE':
        return{
          ...state,
          collegesList:[],
          error:action.payload
        }
        case 'FETCH_CITIES_SUCCESS':
          return{
            ...state,
            cities:action.payload,
            error:''
          }
      default : return state
    }
  }
  export default collesListReducer
  