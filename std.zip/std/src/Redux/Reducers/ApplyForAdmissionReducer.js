const initialState = {
  studentAdmissionInfo: [],
  error: '',
  admissionCount: 0
}
const applyAdmissinReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'FETCH_STUDENT_ADMISSION_INFO_SUCCESS':
      return {
        ...state,
        studentAdmissionInfo: action.payload,
        error: '',
        admissionCount: action.payload.length
      }
    case 'FETCH_STUDENT_ADMISSION_INFO_FAILURE':
      return {
        ...state,
        studentAdmissionInfo: [],
        error: action.payload
      }
    default: return state
  }
}
export default applyAdmissinReducer