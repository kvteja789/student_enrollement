const initialState = {
  userDetails: {},
  is_login : false
}
const loginReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'UPDATE_DETAILS':
      return {
        ...state,
        userDetails: action.payload,
        is_login : true
      }
    case 'LOGOUT':
      return {
        ...state,
        is_login: false
      }
    default: return state
  }
}
export default loginReducer
