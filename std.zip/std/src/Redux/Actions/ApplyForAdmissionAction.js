import axios from 'axios';

export const applyForAdmission = (data) => {
    //console.log('teja-applyforadmission-data-', data);
    const trackingId = Math.floor((Math.random()*1000));
    if(data){
        data.status = "pending";
        data.trackingId = trackingId;
    } 
    else console.log('data is not available');
    return (dispatch) => {
        axios.post(`http://localhost:3000/application`, data).then(res => {
            console.log('teja--applyforadmission-response-', res.data);
            dispatch(fetchStudentAdmissionInfo(data.user_name));
        }).catch(err => {
            alert('Already submitted');
        })
    }
}

export const fetchStudentAdmissionInfo = () => {
    return (dispatch) => {
        axios.get("http://localhost:3000/application")
            .then(response => {
                const studentAdmissionDetails = response.data;
                dispatch(fetchStudentAdmissionInfoSuccess(studentAdmissionDetails))
            })
            .catch(error => {
                const errorMsg = error.message
                dispatch(fetchStudentAdmissionInfoFailure(errorMsg))
            })
    }
}
const fetchStudentAdmissionInfoSuccess = booksList => {
    return {
        type: 'FETCH_STUDENT_ADMISSION_INFO_SUCCESS',
        payload: booksList
    }
}
const fetchStudentAdmissionInfoFailure = error => {
    return {
        type: 'FETCH_STUDENT_ADMISSION_INFO_FAILURE',
        payload: error
    }
}