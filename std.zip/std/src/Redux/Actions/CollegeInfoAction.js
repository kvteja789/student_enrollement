import axios from 'axios';

export const fetchCollegesList = () => {
    return (dispatch) => {
        axios.get(`http://localhost:3000/collegeinfo`)
            .then(response => {
                const collegesList = response.data;
                dispatch(fetchCollegesListSuccess(collegesList))
            })
            .catch(error => {
                const errorMsg = error.message
                dispatch(fetchCollegesListFailure(errorMsg))
            })
    }
}
const fetchCollegesListSuccess = collegesList => {
    return {
        type: 'FETCH_COLLEGES_SUCCESS',
        payload: collegesList
    }
}
const fetchCollegesListFailure = error => {
    return {
        type: 'FETCH_COLLEGES_FAILURE',
        payload: error
    }
}


export const fetchCities = () => {
    return (dispatch) => {
        axios.get(`http://localhost:3000/cities`)
            .then(response => {
                const cities = response.data;
                dispatch(fetchCitiesListSuccess(cities))
            })
            .catch(error => {
                console.log('fetchCities-', error);
            })
    }
}
const fetchCitiesListSuccess = cities => {
    return {
        type: 'FETCH_CITIES_SUCCESS',
        payload: cities
    }
}



