import axios from 'axios';
import validateCredentials from '../../Utility/ValidateCreds';

export const UserLogin = (user_creds) => {
  return (dispatch) => {
    return axios.get(`http://localhost:3000/userDetails/${user_creds.name}`).then((res) => {
      let obj = validateCredentials(res.data, user_creds);
      dispatch(updateDetails(obj));
    });
  };
};
const updateDetails = (obj) => {
  return { type: 'UPDATE_DETAILS', payload: obj };
};
export const logout = () => {
  return {
    type: "LOGOUT",
    payload: false
  };
};





